<?php
echo '<div id="footer">
        <div class="container">
        	<div class="row">
        		<div class="col-md-3 col-sm-3 col-xs-6 footer_columns">
        			<div class="row_heading">Handybooks</div>
        			<ul>
        				<li><a href="about_us">
        					About us
                            </a>
        				</li>
        				<li><a href="our_story">
        					Our story
                            </a>
        				</li>
        				<!-- <li>
        					Mobile site
        				</li> -->
        				<!-- <li>
        					Blog
        				</li> -->
        				<!--<li>
        					Handybooks app <i class="text-muted">( Coming Soon )</i>
        				</li>-->
        			</ul>

        		</div>
        		<div class="col-md-3 col-sm-3 col-xs-6 footer_columns">
        			<div class="row_heading">Support</div>
        			<ul>
                    	<li><a href="how_it_works">
        					Get started
                            </a>
        				</li>
        				<li>
                        <a href="contact">
        					Contact
                            </a>
        				</li>
        				<li><a href="feedback">
        					Feedback
                            </a>
        				</li>
        			</ul>	
        		</div>
        		<div class="col-md-3 col-sm-3 col-xs-6 footer_columns">
        				
        			<div class="row_heading">Legal</div>
        			<ul>
        				<li><a href="terms">
        					Terms and Conditions
                            </a>
        				</li>
        				<li>
                        <a href="privacy">
        					Privacy
                            </a>
        				</li>
                        <li>
        			</ul>	
        		</div>
        		<div class="col-md-3 col-sm-3 col-xs-6 footer_columns">
        			
        				<div class="row_heading">
                            Connect with Handybooks
        				</div>
        			<ul>	
        				<li>
                        <a href="http://twitter.com/handybooksin"><span>
                        <i class="fa fa-twitter fa-2x"></i>&nbsp;&nbsp; 
                        </span>Follow us on twitter
                        </a>
        				</li>
        				<li>
        				<a href="http://www.facebook.com/handybooks"><span>
                        <i class="fa fa-facebook  fa-2x"></i>&nbsp;&nbsp;&nbsp;&nbsp;
                        </span>Like us on facebook
                        </a>
        				</li>
        				<li>
                            <a href="http://plus.google.com/+HandybooksIn"><span>
                        <i class="fa fa-google-plus  fa-2x"></i>&nbsp;&nbsp;
                        </span>
        					Handybooks on Google+
                        </a>
        				</li>
        			</ul>	
        		</div>
        	</div>
            <div class="row">
                <a href="home" onmouseover = "document.getElementsByClassName("in").style.visibility=&apos;visible&apos;" onmouseout = "document.getElementsByClassName("in").style.visibility=&apos;hidden&apos;" class="logo_text">
                    <strong>handybooks</strong>
                    <small class="in">.in</small>
                </a>
                <i>Happy Reading...</i>
            </div>
        </div>
    </div>';
?>