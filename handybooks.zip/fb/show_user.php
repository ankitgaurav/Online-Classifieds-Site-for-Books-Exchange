<?php
include('files/config.php');
echo $_SESSION["facebook_access_token"];
?>